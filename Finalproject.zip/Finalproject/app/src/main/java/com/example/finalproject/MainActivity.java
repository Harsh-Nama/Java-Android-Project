package com.example.finalproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText username, password;
    private MaterialButton loginbtn;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginbtn = findViewById(R.id.loginbtn);

        loginbtn.setOnClickListener(v -> {
            String username1 = username.getText().toString().trim();
            String password1 = password.getText().toString().trim();

            if (TextUtils.isEmpty(username1)) {
                username.setError("Username is required.");
                return;
            }

            if (TextUtils.isEmpty(password1)) {
                password.setError("Password is required.");
                return;
            }

            mAuth.signInWithEmailAndPassword(username1, password1).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(MainActivity.this, "Logged in Successfully", Toast.LENGTH_SHORT).show();

                     Intent intent;
                     intent = new Intent(MainActivity.this, Homepage.class);
                     startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });


        Button button = (Button) findViewById(R.id.regbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regis;
                regis = new Intent(MainActivity.this, Registration.class);
                startActivity(regis);
            }
        });

        Button button1 = (Button) findViewById(R.id.forgotpass);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forgot;
                forgot = new Intent(MainActivity.this, Login.class);
                startActivity(forgot);
            }
        });


        ImageButton imageButton;
        imageButton = (ImageButton) findViewById(R.id.googlebutton);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                gotoUrl("https://www.google.com/intl/en-US/gmail/about/");
                Toast.makeText(MainActivity.this, "Google", Toast.LENGTH_SHORT).show();


            }
        });

        ImageButton imageButton2;
        imageButton2 = (ImageButton) findViewById(R.id.facebookbutton);

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.facebook.com/");
                Toast.makeText(MainActivity.this, "Facebook", Toast.LENGTH_SHORT).show();

            }
        });


    }

    void gotoUrl(String s){
        try{
            Uri uri = Uri.parse(s);
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        }
        catch (Exception e){
            Toast.makeText(this, "No website linked", Toast.LENGTH_SHORT).show();
        }
    }
}
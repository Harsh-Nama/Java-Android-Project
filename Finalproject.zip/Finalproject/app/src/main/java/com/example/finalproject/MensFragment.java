package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;


public class MensFragment extends Fragment {

    ListView iv;
    SearchView searchView;
    ArrayAdapter<String> adapter;
    String[] data = {"T-shirts", "Shirts", "Jeans" ,"Trousers", "Sunglasses", "Sportswear"};


    public MensFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_mens, container, false);
        iv = (ListView) view.findViewById(R.id.list1);
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data);
        iv.setAdapter(adapter);


        iv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = data[position];
                if(selectedItem.equals("T-shirts")){
                    // Start TShirts activity
                    Intent intent = new Intent(getActivity(), Tshirts.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Shirts")){
                    // Start Shirts activity
                    Intent intent = new Intent(getActivity(), Shirts.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Jeans")){
                    // Start Jeans activity
                    Intent intent = new Intent(getActivity(), jeans.class);
                    startActivity(intent);
                }
                else if(selectedItem.equals("Trousers")){
                    // Start Trousers activity
                    Intent intent = new Intent(getActivity(), Trousers.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Sunglasses")){
                    // Start Sunglasses activity
                    Intent intent = new Intent(getActivity(), Sunglasses.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Sportswear")){
                    // Start Sportswear activity
                    Intent intent = new Intent(getActivity(), Sportswear.class);
                    startActivity(intent);
                }
            }
        });

        return view;

    }
}
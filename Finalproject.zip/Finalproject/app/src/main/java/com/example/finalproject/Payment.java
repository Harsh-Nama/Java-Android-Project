package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Payment extends AppCompatActivity {

    private TextView paymentTitle, paymentMethodText, cashOnDeliveryText;
    private EditText cardNumber, expiryDate, cvv, name;
    private CardView paymentMethodCard, cashOnDeliveryCard, payButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Initialize UI components
        paymentTitle = findViewById(R.id.payment_title);
        paymentMethodText = findViewById(R.id.payment_method_text);
        cashOnDeliveryText = findViewById(R.id.cash_on_delivery_text);

        cardNumber = findViewById(R.id.card_number);
        expiryDate = findViewById(R.id.expiry_date);
        cvv = findViewById(R.id.cvv);
        name = findViewById(R.id.name);

        paymentMethodCard = findViewById(R.id.payment_method_card);
        cashOnDeliveryCard = findViewById(R.id.cash_on_delivery_card);
        payButton = findViewById(R.id.pay_button);

        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String card = cardNumber.getText().toString();
                String expiry = expiryDate.getText().toString();
                String CVV = cvv.getText().toString();
                String Name = name.getText().toString();

                if (card.isEmpty() || expiry.isEmpty() || CVV.isEmpty() || Name.isEmpty()) {
                    Toast.makeText(Payment.this, "Please enter the credentials.", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(Payment.this , End.class);
                    startActivity(intent);
                }
            }
        });

        cashOnDeliveryCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Payment.this, "Cash on Delivery Selected!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Payment.this, End.class);
                startActivity(intent);
            }
        });


    }
}
package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Registration extends AppCompatActivity {
    private EditText username, password,name, email,phoneno;
    private Button done;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);

        mAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        done = findViewById(R.id.done);


        done.setOnClickListener(v -> {
            String username1 = username.getText().toString().trim();
            String password1 = password.getText().toString().trim();

          /* if (TextUtils.isEmpty(username1)) {
                username.setError("Username is required.");
                return;
            }

            if (TextUtils.isEmpty(password1)) {
                password.setError("Password is required.");
                return;
            }*/

            mAuth.createUserWithEmailAndPassword(username1, password1).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    FirebaseUser user = mAuth.getCurrentUser();
                    Toast.makeText(Registration.this, "User Created: " + user.getEmail(), Toast.LENGTH_SHORT).show();

                    Intent intent;
                    intent = new Intent(Registration.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(Registration.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });

        Button button = (Button) findViewById(R.id.done);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Registration.this, "Registration Successful ", Toast.LENGTH_SHORT).show();

                Intent intent;
                intent = new Intent(Registration.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}
package com.example.finalproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class Cartpage extends AppCompatActivity {

    private ArrayList<CartItem> cartItems;
    private CartAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cartpage);

        cartItems = Cartmanager.getInstance().getItems();

        // Get the ListView and set up the adapter
        ListView itemList = findViewById(R.id.item_list);
        adapter = new CartAdapter(this, cartItems);
        itemList.setAdapter(adapter);

        // Retrieve items from Intent if available
        Intent intent = getIntent();
        if (intent.hasExtra("cartItem")) {
            String item = intent.getStringExtra("cartItem");
            int imageResource = intent.getIntExtra("cartItemImage", 0);
            addItemToCart(item, imageResource);
        }

        Button checkoutButton = findViewById(R.id.checkout_button);
        checkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle checkout action here
                Toast.makeText(Cartpage.this, "Proceeding to checkout", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Cartpage.this, Payment.class);
                startActivity(intent);
            }
        });
    }

    private void addItemToCart(String item, int imageResource) {
        cartItems.add(new CartItem(item, imageResource));
        adapter.notifyDataSetChanged();
        Toast.makeText(this, item + " added to cart", Toast.LENGTH_SHORT).show();
    }

    public void backbtn(View view) {
        startActivity(new Intent(Cartpage.this, Homepage.class));
    }
}

class CartItem {
    String itemName;
    int imageResource;

    public CartItem(String itemName, int imageResource) {
        this.itemName = itemName;
        this.imageResource = imageResource;
    }
}

class CartAdapter extends ArrayAdapter<CartItem> {
    private ArrayList<CartItem> cartItems;

    public CartAdapter(Context context, ArrayList<CartItem> cartItems) {
        super(context, 0, cartItems);
        this.cartItems = cartItems;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.cart_item, parent, false);
        }

        CartItem cartItem = getItem(position);

        TextView textView = view.findViewById(R.id.item_name);
        textView.setText(cartItem.itemName);

        ImageView imageView = view.findViewById(R.id.item_image);
        imageView.setImageResource(cartItem.imageResource);

        return view;
    }
}
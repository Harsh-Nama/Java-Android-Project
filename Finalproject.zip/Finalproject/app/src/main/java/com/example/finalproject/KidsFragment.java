package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

public class KidsFragment extends Fragment {
    ListView iv;
    SearchView searchView;
    ArrayAdapter<String> adapter;
    String[] data = {"Girls Clothing", "Boy Clothing", "Teens", "T-shirts & Polos", "Baby Clothing"};



    public KidsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_kids, container, false);
        iv = (ListView) view.findViewById(R.id.list3);
        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, data);
        iv.setAdapter(adapter);

        iv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = data[position];
                if(selectedItem.equals("Girls Clothing")){
                    // Start TShirts activity
                    Intent intent = new Intent(getActivity(), Girlsclothing.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Boy Clothing")){
                    // Start Shirts activity
                    Intent intent = new Intent(getActivity(), Boysclothing.class);
                    startActivity(intent);
                } else if(selectedItem.equals("Teens")){
                    // Start Jeans activity
                    Intent intent = new Intent(getActivity(), Teens.class);
                    startActivity(intent);
                } else if(selectedItem.equals("T-shirts & Polos")){
                    // Start Trousers activity
                    Intent intent = new Intent(getActivity(), Polos.class);
                    startActivity(intent);
                }  else if(selectedItem.equals("Baby Clothing")){
                    // Start Sportswear activity
                    Intent intent = new Intent(getActivity(), Babysclothing.class);
                    startActivity(intent);
                }
            }
        });


        return view;
    }
}
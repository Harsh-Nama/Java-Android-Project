package com.example.finalproject;

import java.util.ArrayList;

public class Cartmanager {
    private static Cartmanager instance;
    private ArrayList<CartItem> cartItems;

    private Cartmanager() {
        cartItems = new ArrayList<>();
    }

    public static Cartmanager getInstance() {
        if (instance == null) {
            instance = new Cartmanager();
        }
        return instance;
    }

    public void addItem(CartItem item) {
        cartItems.add(item);
    }

    public ArrayList<CartItem> getItems() {
        return cartItems;
    }

    public void clearCart() {
        cartItems.clear();
    }
}
